from .graph import PagesGraph
from .graph_node import GraphNode