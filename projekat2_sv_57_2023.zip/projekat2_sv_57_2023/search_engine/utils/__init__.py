from .strip_text import strip_text
from .relative_path import relative_path